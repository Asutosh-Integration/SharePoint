import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
       def body = message.getBody(String.class);
       ByteArrayOutputStream outputStream = new ByteArrayOutputStream()
       outputStream.write(body.getBytes())
       message.setBody(outputStream.toString())
       return message;
}